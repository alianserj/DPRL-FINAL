---
applyTo: '**'
---
Provide project context and coding guidelines that AI should follow when generating code, answering questions, or reviewing changes.

I need to test this fully and see what changes are left and interpret the graphs and so on before making a report and sibmitting it.